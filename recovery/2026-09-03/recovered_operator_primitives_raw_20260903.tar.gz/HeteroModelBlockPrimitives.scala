package gemmini

import chisel3._
import chisel3.util._

object HeteroQwen2DecoderBlockProgram {
  import HeteroMicroInstruction.flag
  import HeteroPrimitiveCode._

  val program: Seq[HeteroMicroInstruction] = Seq(
    HeteroMicroInstruction(RmsNorm, 0x00, src0 = 0, src1 = 1, dst = 8, m = 0, n = 1),
    HeteroMicroInstruction(MatrixGemm, 0x01, src0 = 8, src1 = 2, dst = 6, m = 0, n = 2, k = 1, index0 = 0),
    HeteroMicroInstruction(VectorAdd, 0x02, flag(HeteroPrimitiveFlags.ApplyBias), src0 = 6, src1 = 3, dst = 6, m = 0, n = 2, k = 4, index0 = 0),
    HeteroMicroInstruction(Rope, 0x03, src0 = 6, src1 = 4, dst = 6, m = 0, n = 2, k = 4, index0 = 0),
    HeteroMicroInstruction(MatrixGemm, 0x04, src0 = 8, src1 = 2, dst = 6, m = 0, n = 3, k = 1, index0 = 1),
    HeteroMicroInstruction(VectorAdd, 0x05, flag(HeteroPrimitiveFlags.ApplyBias), src0 = 6, src1 = 3, dst = 6, m = 0, n = 3, k = 4, index0 = 1),
    HeteroMicroInstruction(Rope, 0x06, src0 = 6, src1 = 4, dst = 6, m = 0, n = 3, k = 4, index0 = 1),
    HeteroMicroInstruction(MatrixGemm, 0x07, src0 = 8, src1 = 2, dst = 6, m = 0, n = 3, k = 1, index0 = 2),
    HeteroMicroInstruction(VectorAdd, 0x08, flag(HeteroPrimitiveFlags.ApplyBias), src0 = 6, src1 = 3, dst = 6, m = 0, n = 3, k = 4, index0 = 2),
    HeteroMicroInstruction(KvAppend, 0x09, flag(HeteroPrimitiveFlags.Stateful), src0 = 6, dst = 5, m = 0, n = 3, k = 4),
    HeteroMicroInstruction(MatrixQk, 0x0a, flag(HeteroPrimitiveFlags.Causal), src0 = 6, src1 = 5, src2 = 14, dst = 6, m = 2, n = 6, k = 4),
    HeteroMicroInstruction(OnlineSoftmax, 0x0b, flag(HeteroPrimitiveFlags.Causal), src0 = 6, src1 = 14, dst = 6, m = 2, n = 6),
    HeteroMicroInstruction(MatrixPv, 0x0c, src0 = 6, src1 = 5, dst = 6, m = 2, n = 4, k = 6),
    HeteroMicroInstruction(MatrixGemm, 0x0d, src0 = 6, src1 = 7, dst = 8, m = 0, n = 1, k = 1),
    HeteroMicroInstruction(VectorAdd, 0x0e, src0 = 0, src1 = 8, dst = 8, m = 0, n = 1),
    HeteroMicroInstruction(RmsNorm, 0x0f, src0 = 8, src1 = 9, dst = 11, m = 0, n = 1),
    HeteroMicroInstruction(MatrixGemm, 0x10, src0 = 11, src1 = 10, dst = 11, m = 0, n = 5, k = 1, index0 = 0),
    HeteroMicroInstruction(MatrixGemm, 0x11, src0 = 11, src1 = 10, dst = 6, m = 0, n = 5, k = 1, index0 = 1),
    HeteroMicroInstruction(Silu, 0x12, src0 = 11, dst = 11, m = 0, n = 5),
    HeteroMicroInstruction(VectorMul, 0x13, src0 = 11, src1 = 6, dst = 11, m = 0, n = 5),
    HeteroMicroInstruction(MatrixGemm, 0x14, src0 = 11, src1 = 12, dst = 11, m = 0, n = 1, k = 5),
    HeteroMicroInstruction(VectorAdd, 0x15, flag(HeteroPrimitiveFlags.Last), src0 = 8, src1 = 11, dst = 13, m = 0, n = 1),
    HeteroMicroInstruction(StateCommit, 0x16, flag(HeteroPrimitiveFlags.Stateful, HeteroPrimitiveFlags.Commit, HeteroPrimitiveFlags.Last), src0 = 15, dst = 15)
  )
}

class HeteroQwen2DecoderBlockOperatorPrimitive(descriptorBits: Int = 24, dimensionBits: Int = 16, tagBits: Int = 16)
  extends HeteroCompositeOperatorPrimitive(HeteroQwen2DecoderBlockProgram.program, "HeteroQwen2DecoderBlockOperatorPrimitive", descriptorBits, dimensionBits, tagBits)

object HeteroQwen35AttentionProgram {
  import HeteroMicroInstruction.flag
  import HeteroPrimitiveCode._
  val program: Seq[HeteroMicroInstruction] = Seq(
    HeteroMicroInstruction(MatrixGemm, 0x00, src0 = 0, src1 = 1, dst = 6, m = 0, n = 2, k = 1, index0 = 0),
    HeteroMicroInstruction(MatrixGemm, 0x01, src0 = 0, src1 = 1, dst = 6, m = 0, n = 3, k = 1, index0 = 1),
    HeteroMicroInstruction(MatrixGemm, 0x02, src0 = 0, src1 = 1, dst = 6, m = 0, n = 3, k = 1, index0 = 2),
    HeteroMicroInstruction(MatrixGemm, 0x03, src0 = 0, src1 = 2, dst = 7, m = 0, n = 2, k = 1),
    HeteroMicroInstruction(RmsNorm, 0x04, src0 = 6, src1 = 3, dst = 6, m = 0, n = 2, k = 4, index0 = 0),
    HeteroMicroInstruction(RmsNorm, 0x05, src0 = 6, src1 = 3, dst = 6, m = 0, n = 3, k = 4, index0 = 1),
    HeteroMicroInstruction(Rope, 0x06, flag(HeteroPrimitiveFlags.PartialRotary, HeteroPrimitiveFlags.MropeInterleaved), src0 = 6, src1 = 4, dst = 6, m = 0, n = 2, k = 4),
    HeteroMicroInstruction(KvAppend, 0x07, flag(HeteroPrimitiveFlags.Stateful), src0 = 6, dst = 5, m = 0, n = 3, k = 4),
    HeteroMicroInstruction(MatrixQk, 0x08, flag(HeteroPrimitiveFlags.Causal), src0 = 6, src1 = 5, dst = 8, m = 2, n = 6, k = 4),
    HeteroMicroInstruction(OnlineSoftmax, 0x09, flag(HeteroPrimitiveFlags.Causal), src0 = 8, dst = 8, m = 2, n = 6),
    HeteroMicroInstruction(MatrixPv, 0x0a, src0 = 8, src1 = 5, dst = 8, m = 2, n = 4, k = 6),
    HeteroMicroInstruction(Sigmoid, 0x0b, src0 = 7, dst = 7, m = 0, n = 2, k = 4),
    HeteroMicroInstruction(VectorMul, 0x0c, src0 = 8, src1 = 7, dst = 8, m = 0, n = 2, k = 4),
    HeteroMicroInstruction(MatrixGemm, 0x0d, flag(HeteroPrimitiveFlags.Last), src0 = 8, src1 = 9, dst = 10, m = 0, n = 1, k = 2)
  )
}
class HeteroQwen35DenseAttentionOperatorPrimitive(descriptorBits: Int = 24, dimensionBits: Int = 16, tagBits: Int = 16)
  extends HeteroCompositeOperatorPrimitive(HeteroQwen35AttentionProgram.program, "HeteroQwen35DenseAttentionOperatorPrimitive", descriptorBits, dimensionBits, tagBits)

object HeteroLanguageModelBoundaryProgram {
  import HeteroPrimitiveCode._
  val program: Seq[HeteroMicroInstruction] = Seq(
    HeteroMicroInstruction(EmbeddingLookup, 0x00, src0 = 0, src1 = 1, dst = 2, m = 0, n = 1),
    HeteroMicroInstruction(RmsNorm, 0x01, src0 = 3, src1 = 4, dst = 5, m = 0, n = 1),
    HeteroMicroInstruction(MatrixGemv, 0x02, src0 = 5, src1 = 6, dst = 7, m = 0, n = 2, k = 1),
    HeteroMicroInstruction(Argmax, 0x03, flags = HeteroMicroInstruction.flag(HeteroPrimitiveFlags.Last), src0 = 7, dst = 8, n = 2)
  )
}
class HeteroLanguageModelBoundaryOperatorPrimitive(descriptorBits: Int = 24, dimensionBits: Int = 16, tagBits: Int = 16)
  extends HeteroCompositeOperatorPrimitive(HeteroLanguageModelBoundaryProgram.program, "HeteroLanguageModelBoundaryOperatorPrimitive", descriptorBits, dimensionBits, tagBits)

object HeteroMtpDraftProgram {
  import HeteroMicroInstruction.flag
  import HeteroPrimitiveCode._
  val program: Seq[HeteroMicroInstruction] = Seq(
    HeteroMicroInstruction(StateRead, 0x00, flag(HeteroPrimitiveFlags.Stateful), src0 = 0, dst = 1),
    HeteroMicroInstruction(SubgraphLaunch, 0x01, flag(HeteroPrimitiveFlags.Stateful), src0 = 2, src1 = 1, dst = 3, m = 0),
    HeteroMicroInstruction(MatrixGemv, 0x02, src0 = 3, src1 = 4, dst = 5, m = 0, n = 1, k = 2),
    HeteroMicroInstruction(Argmax, 0x03, src0 = 5, dst = 6, m = 0, n = 1),
    HeteroMicroInstruction(SubgraphLaunch, 0x04, flag(HeteroPrimitiveFlags.Stateful), src0 = 7, src1 = 1, dst = 8, m = 0),
    HeteroMicroInstruction(MatrixGemv, 0x05, src0 = 8, src1 = 9, dst = 10, m = 0, n = 1, k = 2),
    HeteroMicroInstruction(Argmax, 0x06, flag(HeteroPrimitiveFlags.Last), src0 = 10, dst = 11, m = 0, n = 1)
  )
}
class HeteroMtpDraftTargetOperatorPrimitive(descriptorBits: Int = 24, dimensionBits: Int = 16, tagBits: Int = 16)
  extends HeteroCompositeOperatorPrimitive(HeteroMtpDraftProgram.program, "HeteroMtpDraftTargetOperatorPrimitive", descriptorBits, dimensionBits, tagBits)

class HeteroMtpStateAction(val descriptorBits: Int = 24, val dimensionBits: Int = 16, val tagBits: Int = 16, val domainBits: Int = 16, val generationBits: Int = 16, val countBits: Int = 8) extends Module {
  val io = IO(new Bundle {
    val start = Flipped(Decoupled(new Bundle { val decision = new HeteroMtpDecision(countBits, domainBits, generationBits); val journalDescriptor = UInt(descriptorBits.W); val tag = UInt(tagBits.W) }))
    val microOp = Decoupled(new HeteroTensorMicroOp(descriptorBits, dimensionBits, tagBits))
    val completion = Flipped(Decoupled(new HeteroPrimitiveCompletion(tagBits)))
    val result = Decoupled(new HeteroOperatorResult(tagBits))
    val busy = Output(Bool()); val protocolError = Output(Bool())
  })
  val sIdle :: sIssueCommit :: sWaitCommit :: sIssueRollback :: sWaitRollback :: sResult :: Nil = Enum(6)
  val state = RegInit(sIdle); val decision = Reg(new HeteroMtpDecision(countBits, domainBits, generationBits)); val journal = Reg(UInt(descriptorBits.W)); val tag = Reg(UInt(tagBits.W)); val status = RegInit(0.U(8.W)); val completed = RegInit(0.U(16.W)); val protocolError = RegInit(false.B)
  val needRollback = decision.mismatch && decision.rollbackDomainMask =/= 0.U
  io.start.ready := state === sIdle
  io.microOp.valid := state === sIssueCommit || state === sIssueRollback
  io.microOp.bits := 0.U.asTypeOf(io.microOp.bits)
  io.microOp.bits.kind := Mux(state === sIssueRollback, HeteroPrimitiveKind.StateRollback, HeteroPrimitiveKind.StateCommit)
  io.microOp.bits.phase := Mux(state === sIssueRollback, 1.U, 0.U)
  io.microOp.bits.flags := Mux(state === sIssueRollback, (1 << HeteroPrimitiveFlags.Stateful | 1 << HeteroPrimitiveFlags.Rollback).U, (1 << HeteroPrimitiveFlags.Stateful | 1 << HeteroPrimitiveFlags.Commit).U)
  io.microOp.bits.src0 := journal; io.microOp.bits.dst := journal; io.microOp.bits.m := decision.acceptedPrefix; io.microOp.bits.n := decision.rollbackTokens; io.microOp.bits.index0 := decision.nextGeneration; io.microOp.bits.index1 := Mux(state === sIssueRollback, decision.rollbackDomainMask, decision.commitDomainMask); io.microOp.bits.tag := tag
  io.completion.ready := state === sWaitCommit || state === sWaitRollback
  io.result.valid := state === sResult; io.result.bits.tag := tag; io.result.bits.status := status; io.result.bits.completedSteps := completed
  io.busy := state =/= sIdle; io.protocolError := protocolError
  when(state === sIdle) { when(io.start.fire) { decision := io.start.bits.decision; journal := io.start.bits.journalDescriptor; tag := io.start.bits.tag; status := 0.U; completed := 0.U; protocolError := false.B; when(io.start.bits.decision.acceptedPrefix =/= 0.U && io.start.bits.decision.commitDomainMask =/= 0.U) { state := sIssueCommit }.elsewhen(io.start.bits.decision.mismatch && io.start.bits.decision.rollbackDomainMask =/= 0.U) { state := sIssueRollback }.otherwise { state := sResult } } }
    .elsewhen(state === sIssueCommit) { when(io.microOp.fire) { state := sWaitCommit } }
    .elsewhen(state === sWaitCommit) { when(io.completion.fire) { val tagMatches = io.completion.bits.tag === tag; val nextStatus = Mux(tagMatches, io.completion.bits.status, "hfe".U); completed := completed + 1.U; when(!tagMatches) { protocolError := true.B }; when(nextStatus =/= 0.U) { status := nextStatus; state := sResult }.elsewhen(needRollback) { state := sIssueRollback }.otherwise { state := sResult } } }
    .elsewhen(state === sIssueRollback) { when(io.microOp.fire) { state := sWaitRollback } }
    .elsewhen(state === sWaitRollback) { when(io.completion.fire) { val tagMatches = io.completion.bits.tag === tag; status := Mux(tagMatches, io.completion.bits.status, "hfe".U); completed := completed + 1.U; when(!tagMatches) { protocolError := true.B }; state := sResult } }
    .elsewhen(state === sResult) { when(io.result.fire) { state := sIdle } }
}

class HeteroVisionEncoderLoopController(val maxDepth: Int = 64, val layerBits: Int = 6) extends Module {
  require(maxDepth >= 1); require((1 << layerBits) >= maxDepth)
  val io = IO(new Bundle { val start = Input(Bool()); val depth = Input(UInt(layerBits.W)); val stageValid = Output(Bool()); val stageReady = Input(Bool()); val stage = Output(UInt(2.W)); val layer = Output(UInt(layerBits.W)); val busy = Output(Bool()); val done = Output(Bool()); val invalidDepth = Output(Bool()) })
  val sIdle :: sPatch :: sBlocks :: sMerge :: Nil = Enum(4); val state = RegInit(sIdle); val depth = Reg(UInt(layerBits.W)); val layer = Reg(UInt(layerBits.W)); val donePulse = RegInit(false.B); val invalidDepth = RegInit(false.B)
  io.stageValid := state =/= sIdle; io.stage := Mux(state === sPatch, 0.U, Mux(state === sBlocks, 1.U, 2.U)); io.layer := layer; io.busy := state =/= sIdle; io.done := donePulse; io.invalidDepth := invalidDepth; donePulse := false.B
  when(state === sIdle) { when(io.start) { val valid = io.depth =/= 0.U && io.depth <= maxDepth.U; invalidDepth := !valid; depth := Mux(valid, io.depth, 1.U); layer := 0.U; state := sPatch } }
    .elsewhen(io.stageValid && io.stageReady) { when(state === sPatch) { layer := 0.U; state := sBlocks }.elsewhen(state === sBlocks) { when(layer + 1.U >= depth) { state := sMerge }.otherwise { layer := layer + 1.U } }.otherwise { state := sIdle; donePulse := true.B } }
}

object HeteroModelStage {
  val Width = 5
  val InputNorm = 0.U(Width.W); val Gdn = 1.U(Width.W); val DenseAttention = 2.U(Width.W); val Qsa = 3.U(Width.W); val Ple = 4.U(Width.W); val GatedResidualRead = 5.U(Width.W); val GatedResidualWrite = 6.U(Width.W); val ResidualAdd = 7.U(Width.W); val PostNorm = 8.U(Width.W); val Moe = 9.U(Width.W); val FinalNorm = 10.U(Width.W)
}

class HeteroQwen35LayerController extends Module {
  val io = IO(new Bundle { val start = Input(Bool()); val fullAttention = Input(Bool()); val stageValid = Output(Bool()); val stageReady = Input(Bool()); val stage = Output(UInt(HeteroModelStage.Width.W)); val busy = Output(Bool()); val done = Output(Bool()) })
  val sIdle :: sInputNorm :: sMixer :: sResidual0 :: sPostNorm :: sMoe :: sResidual1 :: Nil = Enum(7); val state = RegInit(sIdle); val fullAttention = RegInit(false.B); val donePulse = RegInit(false.B)
  io.stageValid := state =/= sIdle; io.stage := MuxLookup(state, HeteroModelStage.InputNorm)(Seq(sInputNorm -> HeteroModelStage.InputNorm, sMixer -> Mux(fullAttention, HeteroModelStage.DenseAttention, HeteroModelStage.Gdn), sResidual0 -> HeteroModelStage.ResidualAdd, sPostNorm -> HeteroModelStage.PostNorm, sMoe -> HeteroModelStage.Moe, sResidual1 -> HeteroModelStage.ResidualAdd)); io.busy := state =/= sIdle; io.done := donePulse; donePulse := false.B
  when(state === sIdle) { when(io.start) { fullAttention := io.fullAttention; state := sInputNorm } }.elsewhen(io.stageValid && io.stageReady) { switch(state) { is(sInputNorm) { state := sMixer }; is(sMixer) { state := sResidual0 }; is(sResidual0) { state := sPostNorm }; is(sPostNorm) { state := sMoe }; is(sMoe) { state := sResidual1 }; is(sResidual1) { state := sIdle; donePulse := true.B } } }
}
class HeteroQwen38LayerController extends Module {
  val io = IO(new Bundle { val start = Input(Bool()); val usePle = Input(Bool()); val qsaLayer = Input(Bool()); val stageValid = Output(Bool()); val stageReady = Input(Bool()); val stage = Output(UInt(HeteroModelStage.Width.W)); val busy = Output(Bool()); val done = Output(Bool()) })
  val sIdle :: sPle :: sRead0 :: sNorm0 :: sMixer :: sWrite0 :: sRead1 :: sNorm1 :: sMoe :: sWrite1 :: Nil = Enum(10); val state = RegInit(sIdle); val usePle = RegInit(false.B); val qsaLayer = RegInit(false.B); val donePulse = RegInit(false.B)
  io.stageValid := state =/= sIdle; io.stage := MuxLookup(state, HeteroModelStage.Ple)(Seq(sPle -> HeteroModelStage.Ple, sRead0 -> HeteroModelStage.GatedResidualRead, sNorm0 -> HeteroModelStage.InputNorm, sMixer -> Mux(qsaLayer, HeteroModelStage.Qsa, HeteroModelStage.Gdn), sWrite0 -> HeteroModelStage.GatedResidualWrite, sRead1 -> HeteroModelStage.GatedResidualRead, sNorm1 -> HeteroModelStage.PostNorm, sMoe -> HeteroModelStage.Moe, sWrite1 -> HeteroModelStage.GatedResidualWrite)); io.busy := state =/= sIdle; io.done := donePulse; donePulse := false.B
  when(state === sIdle) { when(io.start) { usePle := io.usePle; qsaLayer := io.qsaLayer; state := Mux(io.usePle, sPle, sRead0) } }.elsewhen(io.stageValid && io.stageReady) { switch(state) { is(sPle) { state := sRead0 }; is(sRead0) { state := sNorm0 }; is(sNorm0) { state := sMixer }; is(sMixer) { state := sWrite0 }; is(sWrite0) { state := sRead1 }; is(sRead1) { state := sNorm1 }; is(sNorm1) { state := sMoe }; is(sMoe) { state := sWrite1 }; is(sWrite1) { state := sIdle; donePulse := true.B } } }
}
