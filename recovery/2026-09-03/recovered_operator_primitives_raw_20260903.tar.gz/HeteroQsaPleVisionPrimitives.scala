package gemmini

import chisel3._
import chisel3.util._

class HeteroNgramHeadConfig(val headBits: Int = 5) extends Bundle {
  val order = UInt(2.W)
  val tableSize = UInt(32.W)
  val tableOffset = UInt(64.W)
  val head = UInt(headBits.W)
  val last = Bool()
  override def cloneType: this.type =
    new HeteroNgramHeadConfig(headBits).asInstanceOf[this.type]
}

class HeteroNgramRowIndex(val headBits: Int = 5) extends Bundle {
  val row = UInt(64.W)
  val head = UInt(headBits.W)
  val last = Bool()
  override def cloneType: this.type =
    new HeteroNgramRowIndex(headBits).asInstanceOf[this.type]
}

/**
  * PLE N-gram index primitive.
  *
  * Token zero is the caller-provided sentinel for unavailable history. Odd
  * 64-bit multipliers are generated once by software and stored in a model
  * descriptor.  This module implements the modulo-2^64 multiply/XOR hash and
  * per-head table modulus used by the Qwen3.8 PLE path.
  */
class HeteroNgramHash(
    val maxOrder: Int = 3,
    val tokenBits: Int = 20,
    val maxHeads: Int = 16
) extends Module {
  require(maxOrder >= 2)
  require(maxHeads >= 1)
  private val headBits = math.max(1, log2Ceil(maxHeads))

  val io = IO(new Bundle {
    val start = Input(Bool())
    val tokens = Input(Vec(maxOrder, UInt(tokenBits.W)))
    val multipliers = Input(Vec(maxOrder, UInt(64.W)))
    val headConfig = Flipped(Decoupled(new HeteroNgramHeadConfig(headBits)))
    val rowIndex = Decoupled(new HeteroNgramRowIndex(headBits))
    val busy = Output(Bool())
    val done = Output(Bool())
    val invalidConfig = Output(Bool())
  })

  val active = RegInit(false.B)
  val tokens = Reg(Vec(maxOrder, UInt(tokenBits.W)))
  val multipliers = Reg(Vec(maxOrder, UInt(64.W)))
  val outValid = RegInit(false.B)
  val outRow = Reg(UInt(64.W))
  val outHead = Reg(UInt(headBits.W))
  val outLast = RegInit(false.B)
  val invalidConfig = RegInit(false.B)
  val donePulse = RegInit(false.B)

  io.headConfig.ready := active && !outValid
  io.rowIndex.valid := outValid
  io.rowIndex.bits.row := outRow
  io.rowIndex.bits.head := outHead
  io.rowIndex.bits.last := outLast
  io.busy := active || outValid
  io.done := donePulse
  io.invalidConfig := invalidConfig
  donePulse := false.B

  when(!active && !outValid && io.start) {
    tokens := io.tokens
    multipliers := io.multipliers
    invalidConfig := false.B
    active := true.B
  }

  when(io.headConfig.fire) {
    val mixed = Wire(Vec(maxOrder, UInt(64.W)))
    for (index <- 0 until maxOrder) {
      val product = (tokens(index) * multipliers(index))(63, 0)
      mixed(index) := Mux(index.U < io.headConfig.bits.order, product, 0.U)
    }
    val hash = mixed.reduce(_ ^ _)
    val validOrder = io.headConfig.bits.order >= 2.U && io.headConfig.bits.order <= maxOrder.U
    val validSize = io.headConfig.bits.tableSize =/= 0.U
    val modulo = Mux(validSize, hash % io.headConfig.bits.tableSize, 0.U)
    outRow := io.headConfig.bits.tableOffset + modulo
    outHead := io.headConfig.bits.head
    outLast := io.headConfig.bits.last
    outValid := true.B
    when(!validOrder || !validSize) {
      invalidConfig := true.B
    }
    when(io.headConfig.bits.last) {
      active := false.B
    }
  }

  when(io.rowIndex.fire) {
    outValid := false.B
    when(outLast) {
      donePulse := true.B
    }
  }
}

object HeteroGatedResidualProgram {
  import HeteroMicroInstruction.flag
  import HeteroPrimitiveCode._

  /**
    * Descriptor slots:
    *   0 hyper_state, 1 down_weight, 2 up_weight, 3 inject_weight,
    *   4 norm_scratch, 5 low_rank_scratch, 6 read_gate_scratch,
    *   7 mixed_hidden, 8 block_output, 9 injection_weights,
    *   10 updated_hyper, 11 branch_scale, 12-14 reserved, 15 journal.
    * Dimension slots:
    *   0 tokens, 1 branches, 2 hidden, 3 low_rank, 4 branch_hidden,
    *   5-7 reserved.
    */
  val program: Seq[HeteroMicroInstruction] = Seq(
    HeteroMicroInstruction(GroupRmsNorm, 0x00, src0 = 0, dst = 4, m = 0, n = 1, k = 2),
    HeteroMicroInstruction(MatrixGemm, 0x01, src0 = 4, src1 = 1, dst = 5, m = 0, n = 3, k = 4),
    HeteroMicroInstruction(Reciprocal, 0x02, src0 = 0, dst = 11, n = 1, index0 = 1),
    HeteroMicroInstruction(VectorMul, 0x03, src0 = 5, src1 = 11, dst = 5, m = 0, n = 3),
    HeteroMicroInstruction(Silu, 0x04, src0 = 5, dst = 5, m = 0, n = 3),
    HeteroMicroInstruction(MatrixGemm, 0x05, src0 = 5, src1 = 2, dst = 6, m = 0, n = 4, k = 3),
    HeteroMicroInstruction(Sigmoid, 0x06, src0 = 6, dst = 6, m = 0, n = 4),
    HeteroMicroInstruction(VectorMul, 0x07, src0 = 4, src1 = 6, dst = 7, m = 0, n = 1, k = 2),
    HeteroMicroInstruction(ReduceSum, 0x08, src0 = 7, dst = 7, m = 0, n = 1, k = 2),
    HeteroMicroInstruction(VectorMul, 0x09, src0 = 7, src1 = 11, dst = 7, m = 0, n = 2),
    HeteroMicroInstruction(MatrixGemm, 0x0a, src0 = 4, src1 = 3, dst = 9, m = 0, n = 1, k = 4),
    HeteroMicroInstruction(VectorMul, 0x0b, src0 = 9, src1 = 11, dst = 9, m = 0, n = 1, index0 = 2),
    HeteroMicroInstruction(Sigmoid, 0x0c, src0 = 9, dst = 9, m = 0, n = 1),
    HeteroMicroInstruction(VectorMul, 0x0d, src0 = 8, src1 = 9, dst = 10, m = 0, n = 1, k = 2),
    HeteroMicroInstruction(VectorAdd, 0x0e,
      flag(HeteroPrimitiveFlags.Stateful, HeteroPrimitiveFlags.Last),
      src0 = 0, src1 = 10, dst = 10, m = 0, n = 1, k = 2),
    HeteroMicroInstruction(StateCommit, 0x0f,
      flag(HeteroPrimitiveFlags.Stateful, HeteroPrimitiveFlags.Commit, HeteroPrimitiveFlags.Last),
      src0 = 15, dst = 15)
  )
}

/** Qwen3.8 four-branch gated-residual read/write primitive. */
class HeteroGatedResidualOperatorPrimitive(
    descriptorBits: Int = 24,
    dimensionBits: Int = 16,
    tagBits: Int = 16
) extends HeteroCompositeOperatorPrimitive(
  HeteroGatedResidualProgram.program,
  "HeteroGatedResidualOperatorPrimitive",
  descriptorBits,
  dimensionBits,
  tagBits
)

object HeteroPleProgram {
  import HeteroMicroInstruction.flag
  import HeteroPrimitiveCode._

  /**
    * Descriptor slots:
    *   0 hyper_state, 1 token_history, 2 hash_configuration,
    *   3 row_indices, 4 embedding_table, 5 embedding_scratch,
    *   6 key_weight, 7 value_weight, 8 key_scratch,
    *   9 value_scratch, 10 conv_weight, 11 conv_state,
    *   12 output, 13 vector_scratch, 14 row_cache_metadata,
    *   15 state_journal.
    * Dimension slots:
    *   0 tokens, 1 branches, 2 hidden, 3 ngram_order,
    *   4 ngram_heads, 5 embedding_dim, 6 conv_kernel, 7 dilation.
    */
  val program: Seq[HeteroMicroInstruction] = Seq(
    HeteroMicroInstruction(StateRead, 0x00, flag(HeteroPrimitiveFlags.Stateful), src0 = 1, dst = 13, m = 3),
    HeteroMicroInstruction(NgramHash, 0x01, src0 = 13, src1 = 2, dst = 3, m = 0, n = 3, k = 4),
    HeteroMicroInstruction(EmbeddingLookup, 0x02,
      flag(HeteroPrimitiveFlags.Sparse), src0 = 4, src1 = 3, src2 = 14, dst = 5,
      m = 0, n = 4, k = 5),
    HeteroMicroInstruction(MatrixGemm, 0x03, src0 = 5, src1 = 6, dst = 8, m = 0, n = 1, k = 5),
    HeteroMicroInstruction(MatrixGemm, 0x04, src0 = 5, src1 = 7, dst = 9, m = 0, n = 2, k = 5),
    HeteroMicroInstruction(GroupRmsNorm, 0x05, src0 = 8, dst = 8, m = 0, n = 1, k = 2),
    HeteroMicroInstruction(GroupRmsNorm, 0x06, src0 = 0, dst = 13, m = 0, n = 1, k = 2),
    HeteroMicroInstruction(MatrixQk, 0x07, src0 = 13, src1 = 8, dst = 13, m = 0, n = 1, k = 2),
    HeteroMicroInstruction(SignedSqrt, 0x08, src0 = 13, dst = 13, m = 0, n = 1),
    HeteroMicroInstruction(Sigmoid, 0x09, src0 = 13, dst = 13, m = 0, n = 1),
    HeteroMicroInstruction(VectorMul, 0x0a, src0 = 9, src1 = 13, dst = 9, m = 0, n = 1, k = 2),
    HeteroMicroInstruction(GroupRmsNorm, 0x0b, src0 = 9, dst = 13, m = 0, n = 1, k = 2),
    HeteroMicroInstruction(StateRead, 0x0c, flag(HeteroPrimitiveFlags.Stateful), src0 = 11, dst = 13, n = 1, k = 6),
    HeteroMicroInstruction(DepthwiseConv, 0x0d,
      flag(HeteroPrimitiveFlags.Stateful, HeteroPrimitiveFlags.ApplyActivation),
      src0 = 13, src1 = 10, src2 = 13, dst = 13, m = 0, n = 1, k = 6, index0 = 3),
    HeteroMicroInstruction(StateWrite, 0x0e, flag(HeteroPrimitiveFlags.Stateful), src0 = 13, dst = 11, n = 1, k = 6),
    HeteroMicroInstruction(VectorAdd, 0x0f, src0 = 9, src1 = 13, dst = 12, m = 0, n = 1, k = 2),
    HeteroMicroInstruction(StateWrite, 0x10, flag(HeteroPrimitiveFlags.Stateful), src0 = 13, dst = 1, m = 3),
    HeteroMicroInstruction(StateCommit, 0x11,
      flag(HeteroPrimitiveFlags.Stateful, HeteroPrimitiveFlags.Commit, HeteroPrimitiveFlags.Last),
      src0 = 15, dst = 15)
  )
}

/** Qwen3.8 PLE N-gram sparse-embedding, gate and dilated-convolution primitive. */
class HeteroPleOperatorPrimitive(
    descriptorBits: Int = 24,
    dimensionBits: Int = 16,
    tagBits: Int = 16
) extends HeteroCompositeOperatorPrimitive(
  HeteroPleProgram.program,
  "HeteroPleOperatorPrimitive",
  descriptorBits,
  dimensionBits,
  tagBits
)

object HeteroQsaProgram {
  import HeteroMicroInstruction.flag
  import HeteroPrimitiveCode._

  /**
    * Descriptor slots:
    *   0 hidden, 1 index_weight, 2 raw_index_state, 3 block_summary,
    *   4 ranked_blocks, 5 selected_tokens, 6 q_gate_weight,
    *   7 key_weight, 8 value_weight, 9 qkv_scratch,
    *   10 qsa_kv_cache, 11 sparse_kv_scratch, 12 attention_summary,
    *   13 output_weight, 14 output, 15 state_journal.
    * Dimension slots:
    *   0 tokens, 1 hidden, 2 index_heads, 3 index_dim,
    *   4 query_heads, 5 kv_heads, 6 head_dim, 7 token_budget.
    */
  val program: Seq[HeteroMicroInstruction] = Seq(
    HeteroMicroInstruction(MatrixGemm, 0x00, src0 = 0, src1 = 1, dst = 9, m = 0, n = 2, k = 1),
    HeteroMicroInstruction(L2Norm, 0x01, src0 = 9, dst = 9, m = 0, n = 2, k = 3),
    HeteroMicroInstruction(Rope, 0x02,
      flag(HeteroPrimitiveFlags.PartialRotary, HeteroPrimitiveFlags.MropeInterleaved),
      src0 = 9, dst = 9, m = 0, n = 2, k = 3),
    HeteroMicroInstruction(StateWrite, 0x03, flag(HeteroPrimitiveFlags.Stateful), src0 = 9, dst = 2, m = 0, n = 3),
    HeteroMicroInstruction(ReduceSum, 0x04, src0 = 2, dst = 3, m = 0, n = 3, index0 = 4),
    HeteroMicroInstruction(MatrixQk, 0x05, src0 = 9, src1 = 3, dst = 3, m = 2, n = 0, k = 3),
    HeteroMicroInstruction(StableTopK, 0x06, src0 = 3, dst = 4, m = 0, n = 7, index0 = 4),
    HeteroMicroInstruction(StableSort, 0x07, src0 = 4, dst = 4, m = 0, n = 7),
    HeteroMicroInstruction(SparseGatherRun, 0x08,
      flag(HeteroPrimitiveFlags.Sparse), src0 = 4, dst = 5, m = 0, n = 7, index0 = 4),
    HeteroMicroInstruction(KvGather, 0x09,
      flag(HeteroPrimitiveFlags.Sparse), src0 = 10, src1 = 5, dst = 11, m = 0, n = 5, k = 6),
    HeteroMicroInstruction(MatrixGemm, 0x0a, src0 = 0, src1 = 6, dst = 9, m = 0, n = 4, k = 1, index0 = 0),
    HeteroMicroInstruction(MatrixGemm, 0x0b, src0 = 0, src1 = 7, dst = 9, m = 0, n = 5, k = 1, index0 = 1),
    HeteroMicroInstruction(MatrixGemm, 0x0c, src0 = 0, src1 = 8, dst = 9, m = 0, n = 5, k = 1, index0 = 2),
    HeteroMicroInstruction(RmsNorm, 0x0d, src0 = 9, dst = 9, m = 0, n = 4, k = 6, index0 = 0),
    HeteroMicroInstruction(RmsNorm, 0x0e, src0 = 9, dst = 9, m = 0, n = 5, k = 6, index0 = 1),
    HeteroMicroInstruction(Rope, 0x0f,
      flag(HeteroPrimitiveFlags.PartialRotary, HeteroPrimitiveFlags.MropeInterleaved),
      src0 = 9, dst = 9, m = 0, n = 4, k = 6),
    HeteroMicroInstruction(KvAppend, 0x10, flag(HeteroPrimitiveFlags.Stateful), src0 = 9, dst = 10, m = 0, n = 5, k = 6),
    HeteroMicroInstruction(MatrixQk, 0x11, flag(HeteroPrimitiveFlags.Sparse), src0 = 9, src1 = 11, dst = 12, m = 4, n = 7, k = 6),
    HeteroMicroInstruction(OnlineSoftmax, 0x12,
      flag(HeteroPrimitiveFlags.Causal, HeteroPrimitiveFlags.Sparse),
      src0 = 12, src1 = 11, dst = 12, m = 4, n = 7, k = 6),
    HeteroMicroInstruction(MatrixPv, 0x13, flag(HeteroPrimitiveFlags.Sparse), src0 = 12, src1 = 11, dst = 12, m = 4, n = 6, k = 7),
    HeteroMicroInstruction(Sigmoid, 0x14, src0 = 9, dst = 9, m = 0, n = 4, k = 6, index0 = 3),
    HeteroMicroInstruction(VectorMul, 0x15, src0 = 12, src1 = 9, dst = 12, m = 0, n = 4, k = 6),
    HeteroMicroInstruction(MatrixGemm, 0x16, src0 = 12, src1 = 13, dst = 14, m = 0, n = 1, k = 4),
    HeteroMicroInstruction(StateCommit, 0x17,
      flag(HeteroPrimitiveFlags.Stateful, HeteroPrimitiveFlags.Commit, HeteroPrimitiveFlags.Last),
      src0 = 15, dst = 15)
  )
}

/** Qwen sparse-attention index, selection, gather and sparse-attention primitive. */
class HeteroQsaOperatorPrimitive(
    descriptorBits: Int = 24,
    dimensionBits: Int = 16,
    tagBits: Int = 16
) extends HeteroCompositeOperatorPrimitive(
  HeteroQsaProgram.program,
  "HeteroQsaOperatorPrimitive",
  descriptorBits,
  dimensionBits,
  tagBits
)

object HeteroVisionPatchProgram {
  import HeteroMicroInstruction.flag
  import HeteroPrimitiveCode._
  val program: Seq[HeteroMicroInstruction] = Seq(
    HeteroMicroInstruction(MatrixConv, 0x00,
      flag(HeteroPrimitiveFlags.ApplyBias), src0 = 0, src1 = 1, dst = 2,
      m = 0, n = 1, k = 2, index0 = 3),
    HeteroMicroInstruction(BilinearPosition, 0x01, src0 = 3, src1 = 4, dst = 5, m = 0, n = 1),
    HeteroMicroInstruction(VectorAdd, 0x02, flag(HeteroPrimitiveFlags.Last), src0 = 2, src1 = 5, dst = 6, m = 0, n = 1)
  )
}

/** Conv3D patchification plus learned bilinear position interpolation. */
class HeteroVisionPatchEmbedOperatorPrimitive(
    descriptorBits: Int = 24,
    dimensionBits: Int = 16,
    tagBits: Int = 16
) extends HeteroCompositeOperatorPrimitive(
  HeteroVisionPatchProgram.program,
  "HeteroVisionPatchEmbedOperatorPrimitive",
  descriptorBits,
  dimensionBits,
  tagBits
)

object HeteroVisionBlockProgram {
  import HeteroMicroInstruction.flag
  import HeteroPrimitiveCode._

  /** One non-causal vision transformer block. */
  val program: Seq[HeteroMicroInstruction] = Seq(
    HeteroMicroInstruction(LayerNorm, 0x00, src0 = 0, src1 = 1, dst = 2, m = 0, n = 1),
    HeteroMicroInstruction(MatrixGemm, 0x01, flag(HeteroPrimitiveFlags.ApplyBias), src0 = 2, src1 = 3, dst = 4, m = 0, n = 2, k = 1),
    HeteroMicroInstruction(Rope, 0x02, flag(HeteroPrimitiveFlags.NonCausal), src0 = 4, src1 = 5, dst = 4, m = 0, n = 2, k = 3),
    HeteroMicroInstruction(MatrixQk, 0x03, flag(HeteroPrimitiveFlags.NonCausal), src0 = 4, src1 = 4, dst = 6, m = 2, n = 2, k = 3),
    HeteroMicroInstruction(OnlineSoftmax, 0x04, flag(HeteroPrimitiveFlags.NonCausal), src0 = 6, dst = 6, m = 2, n = 2),
    HeteroMicroInstruction(MatrixPv, 0x05, flag(HeteroPrimitiveFlags.NonCausal), src0 = 6, src1 = 4, dst = 7, m = 2, n = 1, k = 2),
    HeteroMicroInstruction(MatrixGemm, 0x06, src0 = 7, src1 = 8, dst = 7, m = 0, n = 1, k = 1),
    HeteroMicroInstruction(VectorAdd, 0x07, src0 = 0, src1 = 7, dst = 9, m = 0, n = 1),
    HeteroMicroInstruction(LayerNorm, 0x08, src0 = 9, src1 = 10, dst = 2, m = 0, n = 1),
    HeteroMicroInstruction(MatrixGemm, 0x09, flag(HeteroPrimitiveFlags.ApplyBias), src0 = 2, src1 = 11, dst = 4, m = 0, n = 4, k = 1),
    HeteroMicroInstruction(GeluTanh, 0x0a, src0 = 4, dst = 4, m = 0, n = 4),
    HeteroMicroInstruction(MatrixGemm, 0x0b, flag(HeteroPrimitiveFlags.ApplyBias), src0 = 4, src1 = 12, dst = 7, m = 0, n = 1, k = 4),
    HeteroMicroInstruction(VectorAdd, 0x0c, flag(HeteroPrimitiveFlags.Last), src0 = 9, src1 = 7, dst = 13, m = 0, n = 1)
  )
}

/** LayerNorm + non-causal MHA + GELU MLP vision block primitive. */
class HeteroVisionTransformerBlockOperatorPrimitive(
    descriptorBits: Int = 24,
    dimensionBits: Int = 16,
    tagBits: Int = 16
) extends HeteroCompositeOperatorPrimitive(
  HeteroVisionBlockProgram.program,
  "HeteroVisionTransformerBlockOperatorPrimitive",
  descriptorBits,
  dimensionBits,
  tagBits
)

object HeteroVisionMergeProgram {
  import HeteroMicroInstruction.flag
  import HeteroPrimitiveCode._
  val program: Seq[HeteroMicroInstruction] = Seq(
    HeteroMicroInstruction(LayerNorm, 0x00, src0 = 0, src1 = 1, dst = 2, m = 0, n = 1),
    HeteroMicroInstruction(SpatialMerge, 0x01, src0 = 2, dst = 3, m = 0, n = 1, index0 = 2),
    HeteroMicroInstruction(MatrixGemm, 0x02, flag(HeteroPrimitiveFlags.ApplyBias), src0 = 3, src1 = 4, dst = 5, m = 0, n = 2, k = 1),
    HeteroMicroInstruction(GeluTanh, 0x03, src0 = 5, dst = 5, m = 0, n = 2),
    HeteroMicroInstruction(MatrixGemm, 0x04,
      flag(HeteroPrimitiveFlags.ApplyBias, HeteroPrimitiveFlags.Last),
      src0 = 5, src1 = 6, dst = 7, m = 0, n = 3, k = 2)
  )
}

/** Spatial 2x2 patch merge and projection to the text hidden width. */
class HeteroVisionPatchMergeOperatorPrimitive(
    descriptorBits: Int = 24,
    dimensionBits: Int = 16,
    tagBits: Int = 16
) extends HeteroCompositeOperatorPrimitive(
  HeteroVisionMergeProgram.program,
  "HeteroVisionPatchMergeOperatorPrimitive",
  descriptorBits,
  dimensionBits,
  tagBits
)

class HeteroBilinearPositionResult(val addressBits: Int = 24) extends Bundle {
  val addresses = Vec(4, UInt(addressBits.W))
  val weightsQ16 = Vec(4, UInt(17.W))
  override def cloneType: this.type =
    new HeteroBilinearPositionResult(addressBits).asInstanceOf[this.type]
}

/**
  * Address and Q0.32 weight planner for learned 2-D position interpolation.
  * The four weighted vector FMAs are executed by the existing SFU.
  */
class HeteroBilinearPositionPlanner(val addressBits: Int = 24) extends Module {
  val io = IO(new Bundle {
    val in = Flipped(Decoupled(new Bundle {
      val row = UInt(addressBits.W)
      val column = UInt(addressBits.W)
      val height = UInt(addressBits.W)
      val width = UInt(addressBits.W)
      val rowFractionQ16 = UInt(16.W)
      val columnFractionQ16 = UInt(16.W)
    }))
    val out = Decoupled(new HeteroBilinearPositionResult(addressBits))
  })

  val valid = RegInit(false.B)
  val result = Reg(new HeteroBilinearPositionResult(addressBits))
  io.in.ready := !valid || io.out.ready
  io.out.valid := valid
  io.out.bits := result

  when(io.in.ready) {
    valid := io.in.valid
    when(io.in.valid) {
      val safeHeight = Mux(io.in.bits.height === 0.U, 1.U, io.in.bits.height)
      val safeWidth = Mux(io.in.bits.width === 0.U, 1.U, io.in.bits.width)
      val row0 = Mux(io.in.bits.row >= safeHeight, safeHeight - 1.U, io.in.bits.row)
      val col0 = Mux(io.in.bits.column >= safeWidth, safeWidth - 1.U, io.in.bits.column)
      val row1 = Mux(row0 + 1.U >= safeHeight, row0, row0 + 1.U)
      val col1 = Mux(col0 + 1.U >= safeWidth, col0, col0 + 1.U)
      val one = 65536.U(17.W)
      val fr = io.in.bits.rowFractionQ16
      val fc = io.in.bits.columnFractionQ16
      val invR = one - fr
      val invC = one - fc
      result.addresses(0) := row0 * safeWidth + col0
      result.addresses(1) := row0 * safeWidth + col1
      result.addresses(2) := row1 * safeWidth + col0
      result.addresses(3) := row1 * safeWidth + col1
      result.weightsQ16(0) := (invR * invC)(32, 16)
      result.weightsQ16(1) := (invR * fc)(32, 16)
      result.weightsQ16(2) := (fr * invC)(32, 16)
      result.weightsQ16(3) := (fr * fc)(32, 16)
    }
  }
}

class HeteroSpatialMergeIndex(val addressBits: Int = 24) extends Bundle {
  val sourceToken = UInt(addressBits.W)
  val lane = UInt(2.W)
  val last = Bool()
  override def cloneType: this.type =
    new HeteroSpatialMergeIndex(addressBits).asInstanceOf[this.type]
}

/** Emits the four source-token indices for a 2x2 Qwen vision patch merge. */
class HeteroSpatialMergeAddressGenerator(val addressBits: Int = 24) extends Module {
  val io = IO(new Bundle {
    val start = Input(Bool())
    val groupRow = Input(UInt(addressBits.W))
    val groupColumn = Input(UInt(addressBits.W))
    val sourceWidth = Input(UInt(addressBits.W))
    val out = Decoupled(new HeteroSpatialMergeIndex(addressBits))
    val busy = Output(Bool())
    val done = Output(Bool())
  })
  val active = RegInit(false.B)
  val lane = RegInit(0.U(2.W))
  val baseRow = Reg(UInt(addressBits.W))
  val baseColumn = Reg(UInt(addressBits.W))
  val width = Reg(UInt(addressBits.W))
  val donePulse = RegInit(false.B)

  val rowOffset = lane(1)
  val columnOffset = lane(0)
  io.out.valid := active
  io.out.bits.sourceToken := (baseRow + rowOffset) * width + baseColumn + columnOffset
  io.out.bits.lane := lane
  io.out.bits.last := lane === 3.U
  io.busy := active
  io.done := donePulse
  donePulse := false.B

  when(!active && io.start) {
    baseRow := io.groupRow << 1
    baseColumn := io.groupColumn << 1
    width := Mux(io.sourceWidth === 0.U, 1.U, io.sourceWidth)
    lane := 0.U
    active := true.B
  }.elsewhen(io.out.fire) {
    when(lane === 3.U) {
      active := false.B
      donePulse := true.B
    }.otherwise {
      lane := lane + 1.U
    }
  }
}
