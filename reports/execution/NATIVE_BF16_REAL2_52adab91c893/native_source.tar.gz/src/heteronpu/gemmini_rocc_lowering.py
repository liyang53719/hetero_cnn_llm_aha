"""Pinned Gemmini RoCC micro-op encoders used by the L2 descriptor path.

This is intentionally a lowering *primitive*, not a replacement Gemmini model.
It transcribes the official ``gemmini.h`` C macros for the locked
GemminiRocketConfig.  A typed project descriptor supplies the addresses and
tile dimensions; RocketTile still supplies status, PTW and TileLink context.
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import IntEnum


ADDR_LEN = 32
CUSTOM3_OPCODE = 0x7B


class GemminiFunct(IntEnum):
    CONFIG = 0
    MVIN2 = 1
    MVIN = 2
    MVOUT = 3
    COMPUTE_PRELOADED = 4
    COMPUTE_ACCUMULATE = 5
    PRELOAD = 6
    FLUSH = 7
    LOOP_WS = 8
    LOOP_WS_CONFIG_BOUNDS = 9
    LOOP_WS_CONFIG_ADDRS_AB = 10
    LOOP_WS_CONFIG_ADDRS_DC = 11
    LOOP_WS_CONFIG_STRIDES_AB = 12
    LOOP_WS_CONFIG_STRIDES_DC = 13
    MVIN3 = 14
    LOOP_CONV_WS = 15
    LOOP_CONV_WS_CONFIG_1 = 16
    LOOP_CONV_WS_CONFIG_2 = 17
    LOOP_CONV_WS_CONFIG_3 = 18
    LOOP_CONV_WS_CONFIG_4 = 19
    LOOP_CONV_WS_CONFIG_5 = 20
    LOOP_CONV_WS_CONFIG_6 = 21
    MVOUT_SPAD = 23
    COUNTER = 126


class GemminiDataflow(IntEnum):
    """Values used by the pinned official ``gemmini.h`` API."""

    OUTPUT_STATIONARY = 0
    WEIGHT_STATIONARY = 1


@dataclass(frozen=True)
class RoCCMicroOp:
    """One official CUSTOM_3 RoCC instruction as seen by RocketTile."""

    funct: GemminiFunct
    rs1: int
    rs2: int
    # Standard Gemmini C macros use ``ROCC_INSTRUCTION_0_R_R``: no result.
    xd: bool = False
    xs1: bool = True
    xs2: bool = True
    rd: int = 0
    opcode: int = CUSTOM3_OPCODE

    def __post_init__(self) -> None:
        for name, value, bits in (
            ("funct", int(self.funct), 7), ("rs1", self.rs1, 64),
            ("rs2", self.rs2, 64), ("rd", self.rd, 5), ("opcode", self.opcode, 7),
        ):
            if not 0 <= value < (1 << bits):
                raise ValueError(f"{name} does not fit in {bits} bits")
        if self.opcode != CUSTOM3_OPCODE:
            raise ValueError("locked GemminiRocketConfig accepts only CUSTOM_3")

    @property
    def funct3(self) -> int:
        """RISC-V custom funct3 encoding used by pinned ROCC_INSTRUCTION_0_R_R.

        `xcustom.h` emits `.insn r CUSTOM_3, 0x3, funct7, x0, rs1, rs2`.
        In Rocket command terms those bits encode xd=0, xs1=1 and xs2=1.
        """

        return (int(self.xd) << 2) | (int(self.xs1) << 1) | int(self.xs2)


def _unsigned(name: str, value: int, bits: int) -> int:
    if not 0 <= value < (1 << bits):
        raise ValueError(f"{name} does not fit in {bits} bits")
    return value


def pack_local_addr_rows_cols(local_addr: int, cols: int, rows: int) -> int:
    """Exact ``gemmini_extended_*`` address/shape packing from gemmini.h."""

    return (
        _unsigned("local_addr", local_addr, ADDR_LEN)
        | (_unsigned("cols", cols, 16) << ADDR_LEN)
        | (_unsigned("rows", rows, 16) << (ADDR_LEN + 16))
    )


def mvin(dram_addr: int, local_addr: int, cols: int, rows: int, *, channel: int = 0) -> RoCCMicroOp:
    """Encode official mvin/mvin2/mvin3, without inventing DMA behavior."""

    funct = {0: GemminiFunct.MVIN, 1: GemminiFunct.MVIN2, 2: GemminiFunct.MVIN3}.get(channel)
    if funct is None:
        raise ValueError("channel must be 0 (mvin), 1 (mvin2), or 2 (mvin3)")
    return RoCCMicroOp(funct, _unsigned("dram_addr", dram_addr, 64),
                       pack_local_addr_rows_cols(local_addr, cols, rows))


def mvout(dram_addr: int, local_addr: int, cols: int, rows: int) -> RoCCMicroOp:
    return RoCCMicroOp(GemminiFunct.MVOUT, _unsigned("dram_addr", dram_addr, 64),
                       pack_local_addr_rows_cols(local_addr, cols, rows))


def preload(bd_local_addr: int, c_local_addr: int, bd_cols: int, bd_rows: int,
            c_cols: int, c_rows: int) -> RoCCMicroOp:
    return RoCCMicroOp(
        GemminiFunct.PRELOAD,
        pack_local_addr_rows_cols(bd_local_addr, bd_cols, bd_rows),
        pack_local_addr_rows_cols(c_local_addr, c_cols, c_rows),
    )


def compute(a_local_addr: int, bd_local_addr: int, a_cols: int, a_rows: int,
            bd_cols: int, bd_rows: int, *, accumulate: bool) -> RoCCMicroOp:
    return RoCCMicroOp(
        GemminiFunct.COMPUTE_ACCUMULATE if accumulate else GemminiFunct.COMPUTE_PRELOADED,
        pack_local_addr_rows_cols(a_local_addr, a_cols, a_rows),
        pack_local_addr_rows_cols(bd_local_addr, bd_cols, bd_rows),
    )


def flush(*, skip: bool = False) -> RoCCMicroOp:
    """Encode the official TLB flush command; this is not a GEMM completion."""

    return RoCCMicroOp(GemminiFunct.FLUSH, int(skip), 0)


def config_ex(*, dataflow: GemminiDataflow, c_stride: int, a_stride: int,
              a_transpose: bool = False, b_transpose: bool = False,
              sys_activation: int = 0, sys_shift: int = 0,
              acc_scale_bits: int = 0x3F80_0000) -> RoCCMicroOp:
    """Encode ``gemmini_extended3_config_ex`` with explicit frozen operands."""

    rs1 = (
        _unsigned("acc_scale_bits", acc_scale_bits, 32) << 32
        | _unsigned("a_stride", a_stride, 16) << 16
        | int(bool(b_transpose)) << 9
        | int(bool(a_transpose)) << 8
        | _unsigned("sys_activation", sys_activation, 2) << 3
        | _unsigned("dataflow", int(dataflow), 1) << 2
    )
    rs2 = _unsigned("c_stride", c_stride, 16) << 48 | _unsigned("sys_shift", sys_shift, 32)
    return RoCCMicroOp(GemminiFunct.CONFIG, rs1, rs2)


def config_load(*, stride_bytes: int, scale_bits: int = 0x3F80_0000,
                shrunk: bool = False, block_mvin_stride: int = 16,
                pixel_repeats: int = 1, channel: int = 0) -> RoCCMicroOp:
    """Encode ``gemmini_extended5_config_ld`` without hidden defaults."""

    rs1 = (
        _unsigned("scale_bits", scale_bits, 32) << 32
        | _unsigned("block_mvin_stride", block_mvin_stride, 16) << 16
        | _unsigned("pixel_repeats", pixel_repeats, 8) << 8
        | _unsigned("channel", channel, 2) << 3
        | int(bool(shrunk)) << 2
        | 1  # CONFIG_LD
    )
    return RoCCMicroOp(GemminiFunct.CONFIG, rs1, _unsigned("stride_bytes", stride_bytes, 32))


def config_store(*, stride_bytes: int, acc_scale_bits: int = 0x3F80_0000,
                 activation: int = 0) -> RoCCMicroOp:
    """Encode the non-pooling ``gemmini_config_st`` form."""

    rs1 = _unsigned("activation", activation, 2) << 2 | 2
    rs2 = _unsigned("acc_scale_bits", acc_scale_bits, 32) << 32 | _unsigned("stride_bytes", stride_bytes, 32)
    return RoCCMicroOp(GemminiFunct.CONFIG, rs1, rs2)


@dataclass(frozen=True)
class Int8SingleTileDescriptor:
    """Typed L2 descriptor view for one official output-stationary Gemmini tile.

    The architectural descriptor schema owns the logical M/N/K and tensor
    bases.  This object is its resolved one-tile view: local addresses already
    carry official scratchpad/accumulator address bits, so this lowerer never
    invents a memory map.  It deliberately rejects tiles beyond DIM=16 and
    weight-stationary sequencing until the project descriptor allocator and
    official loop path are connected in RocketTile.
    """

    a_dram_addr: int
    b_dram_addr: int
    c_dram_addr: int
    a_local_addr: int
    b_local_addr: int
    c_local_addr: int
    m: int
    n: int
    k: int
    a_stride_bytes: int
    b_stride_bytes: int
    c_stride_bytes: int
    bias_dram_addr: int | None = None
    bias_local_addr: int | None = None
    bias_stride_bytes: int | None = None
    dataflow: GemminiDataflow = GemminiDataflow.OUTPUT_STATIONARY
    transpose_a: bool = False
    transpose_b: bool = False


def lower_int8_single_tile(descriptor: Int8SingleTileDescriptor) -> tuple[RoCCMicroOp, ...]:
    """Lower one resolved OS INT8 tile using the official C macro ordering.

    The returned program intentionally has no synthetic response or completion
    command.  Completion remains a retained-RocketTile observation, because
    normal Gemmini commands do not produce a generic ``io_resp`` transaction.
    """

    for name, value in (("m", descriptor.m), ("n", descriptor.n), ("k", descriptor.k)):
        if not 1 <= value <= 16:
            raise ValueError(f"{name} must be in 1..16 for the single-tile lowerer")
    if descriptor.dataflow is not GemminiDataflow.OUTPUT_STATIONARY:
        raise ValueError("weight-stationary lowering requires the retained official loop path")
    if (descriptor.bias_dram_addr is None) != (descriptor.bias_local_addr is None):
        raise ValueError("bias dram/local addresses must either both be present or both be absent")
    if descriptor.bias_dram_addr is not None and descriptor.bias_stride_bytes is None:
        raise ValueError("bias_stride_bytes is required with a bias descriptor")

    ops = [
        config_ex(
            dataflow=descriptor.dataflow,
            # Match gemmini_config_ex() in the pinned basic OS C path.  DMA
            # row strides are owned by config_st/config_ld below; placing
            # them here changes the official CUSTOM_3 transcript.
            c_stride=1,
            a_stride=1,
            a_transpose=descriptor.transpose_a,
            b_transpose=descriptor.transpose_b,
        ),
        config_store(stride_bytes=descriptor.c_stride_bytes),
        config_load(stride_bytes=descriptor.a_stride_bytes),
        mvin(descriptor.a_dram_addr, descriptor.a_local_addr, descriptor.k, descriptor.m),
        config_load(stride_bytes=descriptor.b_stride_bytes),
        mvin(descriptor.b_dram_addr, descriptor.b_local_addr, descriptor.n, descriptor.k),
    ]
    if descriptor.bias_dram_addr is not None:
        assert descriptor.bias_local_addr is not None and descriptor.bias_stride_bytes is not None
        ops.extend((
            config_load(stride_bytes=descriptor.bias_stride_bytes),
            mvin(descriptor.bias_dram_addr, descriptor.bias_local_addr, descriptor.n, descriptor.m),
            preload(descriptor.bias_local_addr, descriptor.c_local_addr,
                    descriptor.n, descriptor.m, descriptor.n, descriptor.m),
        ))
    else:
        ops.append(preload((1 << 32) - 1, descriptor.c_local_addr,
                           16, 16, descriptor.n, descriptor.m))
    ops.extend((
        compute(descriptor.a_local_addr, descriptor.b_local_addr,
                descriptor.k, descriptor.m, descriptor.n, descriptor.k, accumulate=False),
        mvout(descriptor.c_dram_addr, descriptor.c_local_addr, descriptor.n, descriptor.m),
    ))
    return tuple(ops)


@dataclass(frozen=True)
class LoopWsDescriptor:
    """Exact retained-RocketTile view of the official six-command WS loop."""

    i: int
    j: int
    k: int
    pad_i: int
    pad_j: int
    pad_k: int
    a_addr: int
    b_addr: int
    d_addr: int
    c_addr: int
    a_stride: int
    b_stride: int
    d_stride: int
    c_stride: int
    a_transpose: bool = False
    b_transpose: bool = False
    full_c: bool = False
    low_d: bool = False
    ex_accumulate: bool = True
    activation: int = 0
    a_spad_id: int = 0
    b_spad_id: int = 0
    is_resadd: bool = False


def lower_loop_ws(descriptor: LoopWsDescriptor) -> tuple[RoCCMicroOp, ...]:
    for name, value, bits in (
        ("i", descriptor.i, 16), ("j", descriptor.j, 16), ("k", descriptor.k, 32),
        ("pad_i", descriptor.pad_i, 16), ("pad_j", descriptor.pad_j, 16),
        ("pad_k", descriptor.pad_k, 32), ("a_addr", descriptor.a_addr, 64),
        ("b_addr", descriptor.b_addr, 64), ("d_addr", descriptor.d_addr, 64),
        ("c_addr", descriptor.c_addr, 64), ("a_stride", descriptor.a_stride, 64),
        ("b_stride", descriptor.b_stride, 64), ("d_stride", descriptor.d_stride, 64),
        ("c_stride", descriptor.c_stride, 64), ("activation", descriptor.activation, 8),
        ("a_spad_id", descriptor.a_spad_id, 2), ("b_spad_id", descriptor.b_spad_id, 2),
    ):
        _unsigned(name, value, bits)
    bounds_rs1 = descriptor.pad_k << 32 | descriptor.pad_j << 16 | descriptor.pad_i
    bounds_rs2 = descriptor.k << 32 | descriptor.j << 16 | descriptor.i
    loop_rs1 = (
        descriptor.a_spad_id << 18
        | descriptor.b_spad_id << 16
        | descriptor.activation << 8
        | int(descriptor.low_d) << 2
        | int(descriptor.full_c) << 1
        | int(descriptor.ex_accumulate)
    )
    loop_rs2 = (
        int(descriptor.is_resadd) << 2
        | int(descriptor.b_transpose) << 1
        | int(descriptor.a_transpose)
    )
    return (
        RoCCMicroOp(GemminiFunct.LOOP_WS_CONFIG_BOUNDS, bounds_rs1, bounds_rs2),
        RoCCMicroOp(GemminiFunct.LOOP_WS_CONFIG_ADDRS_AB, descriptor.a_addr, descriptor.b_addr),
        RoCCMicroOp(GemminiFunct.LOOP_WS_CONFIG_ADDRS_DC, descriptor.d_addr, descriptor.c_addr),
        RoCCMicroOp(GemminiFunct.LOOP_WS_CONFIG_STRIDES_AB, descriptor.a_stride, descriptor.b_stride),
        RoCCMicroOp(GemminiFunct.LOOP_WS_CONFIG_STRIDES_DC, descriptor.d_stride, descriptor.c_stride),
        RoCCMicroOp(GemminiFunct.LOOP_WS, loop_rs1, loop_rs2),
    )


@dataclass(frozen=True)
class Int8OsTilesDescriptor:
    """One resolved upstream ``sp_tiled_matmul_os`` invocation.

    This deliberately models one hardware-resident macro tile, not the outer
    DRAM tiler. ``i_tiles/j_tiles/k_tiles`` are counts of 16x16 Gemmini tiles;
    padding applies only to the final tile in each dimension. Bias is INT32
    and output is INT8, matching the pinned L2 case.
    """

    a_addr: int
    b_addr: int
    d_addr: int
    c_addr: int
    i_tiles: int
    j_tiles: int
    k_tiles: int
    pad_i: int
    pad_j: int
    pad_k: int
    a_row_stride: int
    b_row_stride: int
    d_row_stride: int
    c_row_stride: int


def lower_int8_os_tiles(descriptor: Int8OsTilesDescriptor) -> tuple[RoCCMicroOp, ...]:
    """Transcribe pinned upstream ``tiled_matmul_outer`` + OS inner ordering."""

    dim = 16
    bank_rows = 4 * 4096
    garbage_addr = (1 << ADDR_LEN) - 1
    for name, value in (
        ("i_tiles", descriptor.i_tiles), ("j_tiles", descriptor.j_tiles),
        ("k_tiles", descriptor.k_tiles),
    ):
        if not 1 <= value <= 0xFFFF:
            raise ValueError(f"{name} must be in 1..65535")
    for name, value in (
        ("pad_i", descriptor.pad_i), ("pad_j", descriptor.pad_j),
        ("pad_k", descriptor.pad_k),
    ):
        if not 0 <= value < dim:
            raise ValueError(f"{name} must be in 0..15")
    for name in ("a_addr", "b_addr", "d_addr", "c_addr"):
        _unsigned(name, getattr(descriptor, name), 64)
    for name in ("a_row_stride", "b_row_stride", "d_row_stride", "c_row_stride"):
        if getattr(descriptor, name) <= 0:
            raise ValueError(f"{name} must be positive")

    i_tiles, j_tiles, k_tiles = (
        descriptor.i_tiles, descriptor.j_tiles, descriptor.k_tiles
    )
    a_sp_start = 0
    b_sp_start = bank_rows - k_tiles * j_tiles * dim
    d_sp_start = 1 << (ADDR_LEN - 1)
    c_sp_start = 3 << (ADDR_LEN - 2)

    ops: list[RoCCMicroOp] = [
        config_ex(dataflow=GemminiDataflow.OUTPUT_STATIONARY, c_stride=1, a_stride=1),
        config_store(stride_bytes=descriptor.c_row_stride),
        config_load(stride_bytes=descriptor.a_row_stride, channel=0),
        config_load(stride_bytes=descriptor.b_row_stride, channel=1),
        config_load(stride_bytes=descriptor.d_row_stride * 4, channel=2),
        # sp_tiled_matmul_os reselects channel zero for each operand class.
        config_load(stride_bytes=descriptor.d_row_stride * 4, channel=0),
    ]

    # MAX_BLOCK_LEN_ACC is one tile for this locked Gemmini configuration.
    for i in range(i_tiles):
        for j in range(j_tiles):
            cols = dim - (descriptor.pad_j if j == j_tiles - 1 else 0)
            rows = dim - (descriptor.pad_i if i == i_tiles - 1 else 0)
            dram = descriptor.d_addr + (i * descriptor.d_row_stride + j) * dim * 4
            local = d_sp_start + (i * j_tiles + j) * dim
            ops.append(mvin(dram, local, cols, rows))

    ops.append(config_load(stride_bytes=descriptor.b_row_stride, channel=0))
    # MAX_BLOCK_LEN is four tiles, so J=2 is one block in the locked case.
    if j_tiles > 4:
        raise ValueError("pinned OS lowerer currently requires j_tiles <= MAX_BLOCK_LEN=4")
    for k in range(k_tiles):
        cols = j_tiles * dim - descriptor.pad_j
        rows = dim - (descriptor.pad_k if k == k_tiles - 1 else 0)
        dram = descriptor.b_addr + k * dim * descriptor.b_row_stride
        local = b_sp_start + k * j_tiles * dim
        ops.append(mvin(dram, local, cols, rows))

    ops.append(config_load(stride_bytes=descriptor.a_row_stride, channel=0))
    if k_tiles > 4:
        raise ValueError("pinned OS lowerer currently requires k_tiles <= MAX_BLOCK_LEN=4")
    for i in range(i_tiles):
        cols = k_tiles * dim - descriptor.pad_k
        rows = dim - (descriptor.pad_i if i == i_tiles - 1 else 0)
        dram = descriptor.a_addr + i * dim * descriptor.a_row_stride
        local = a_sp_start + i * k_tiles * dim
        ops.append(mvin(dram, local, cols, rows))

    for i in range(i_tiles):
        for j in range(j_tiles):
            c_local = c_sp_start + (i * j_tiles + j) * dim
            c_cols = dim - (descriptor.pad_j if j == j_tiles - 1 else 0)
            c_rows = dim - (descriptor.pad_i if i == i_tiles - 1 else 0)
            for k in range(k_tiles):
                a_local = a_sp_start + (i * k_tiles + k) * dim
                b_local = b_sp_start + (k * j_tiles + j) * dim
                a_cols = dim - (descriptor.pad_k if k == k_tiles - 1 else 0)
                b_rows = a_cols
                b_cols = c_cols
                out_local = c_local if k == k_tiles - 1 else garbage_addr
                ops.append(preload(garbage_addr, out_local, dim, dim, c_cols, c_rows))
                ops.append(compute(a_local, b_local, a_cols, c_rows, b_cols, b_rows,
                                   accumulate=k != 0))

    for i in range(i_tiles):
        for j in range(j_tiles):
            cols = dim - (descriptor.pad_j if j == j_tiles - 1 else 0)
            rows = dim - (descriptor.pad_i if i == i_tiles - 1 else 0)
            dram = descriptor.c_addr + (i * descriptor.c_row_stride + j) * dim
            local = c_sp_start + (i * j_tiles + j) * dim
            ops.append(mvout(dram, local, cols, rows))
    return tuple(ops)


@dataclass(frozen=True)
class ConvWsDescriptor:
    """Exact argument view of pinned ``gemmini_loop_conv_ws``."""

    batch_size: int; in_row_dim: int; in_col_dim: int; in_channels: int
    out_channels: int; out_row_dim: int; out_col_dim: int
    pool_out_row_dim: int; pool_out_col_dim: int
    stride: int; padding: int; kernel_dim: int; kernel_dilation: int
    pool_size: int; pool_stride: int; pool_padding: int
    batches: int; porows: int; pocols: int; pochs: int
    krows: int; kcols: int; kchs: int
    lpad: int; rpad: int; upad: int; dpad: int
    plpad: int; prpad: int; pupad: int; pdpad: int
    orows: int; ocols: int
    weights_addr: int; output_addr: int; bias_addr: int; input_addr: int
    no_bias: bool = False; no_pool: bool = True; downsample: bool = False
    wrot180: bool = False; input_dilated: bool = False; activation: int = 0
    trans_output_1203: bool = False; trans_weight_1203: bool = False
    trans_weight_0132: bool = False; trans_input_3120: bool = False
    max_pixels_per_row: int = 1
    in_stride: int = 1; weight_stride: int = 1; out_stride: int = 1
    dw: bool = False; a_spad_id: int = 0; b_spad_id: int = 0


def lower_loop_conv_ws(descriptor: ConvWsDescriptor) -> tuple[RoCCMicroOp, ...]:
    widths = {
        "batch_size": 16, "in_row_dim": 16, "in_col_dim": 16,
        "in_channels": 16, "out_channels": 16, "out_row_dim": 16,
        "out_col_dim": 16, "pool_out_row_dim": 16, "pool_out_col_dim": 16,
        "stride": 8, "padding": 8, "kernel_dim": 16,
        "kernel_dilation": 10, "pool_size": 16, "pool_stride": 8,
        "pool_padding": 8, "batches": 16, "porows": 16, "pocols": 16,
        "pochs": 16, "krows": 16, "kcols": 16, "kchs": 16,
        "lpad": 16, "rpad": 16, "upad": 16, "dpad": 8,
        "plpad": 8, "prpad": 16, "pupad": 11, "pdpad": 11,
        "orows": 16, "ocols": 16, "activation": 8,
        "max_pixels_per_row": 8, "in_stride": 16,
        "weight_stride": 16, "out_stride": 16,
        "a_spad_id": 2, "b_spad_id": 2,
    }
    for name, bits in widths.items():
        _unsigned(name, getattr(descriptor, name), bits)
    for name in ("weights_addr", "output_addr", "bias_addr", "input_addr"):
        _unsigned(name, getattr(descriptor, name), 64)

    c1_rs1 = (descriptor.out_channels << 48 | descriptor.in_channels << 32 |
              descriptor.in_row_dim << 16 | descriptor.batch_size)
    c1_rs2 = (descriptor.padding << 56 | descriptor.stride << 48 |
              descriptor.out_col_dim << 32 | descriptor.pool_out_row_dim << 16 |
              descriptor.out_row_dim)
    c2_rs1 = (descriptor.kernel_dim << 48 | descriptor.pool_out_col_dim << 32 |
              descriptor.pool_size << 16 | descriptor.pool_stride << 8 |
              descriptor.pool_padding)
    c2_rs2 = (descriptor.batches << 48 | descriptor.porows << 32 |
              descriptor.pocols << 16 | descriptor.pochs)
    c3_rs1 = (descriptor.krows << 48 | descriptor.kcols << 32 |
              descriptor.kchs << 16 | descriptor.lpad)
    c3_rs2 = (descriptor.rpad << 48 | descriptor.upad << 32 |
              descriptor.dpad << 24 | descriptor.plpad << 16 |
              descriptor.in_col_dim)
    c4_rs1 = (descriptor.orows << 48 | descriptor.prpad << 32 |
              descriptor.pupad << 21 | descriptor.pdpad << 10 |
              descriptor.kernel_dilation)
    c4_rs2 = (descriptor.in_stride << 48 | descriptor.weight_stride << 32 |
              descriptor.out_stride << 16 | descriptor.ocols)
    run_rs1 = (descriptor.a_spad_id << 18 | descriptor.b_spad_id << 16 |
               descriptor.max_pixels_per_row << 8 | int(descriptor.dw) << 6 |
               int(descriptor.trans_input_3120) << 5 |
               int(descriptor.trans_weight_0132) << 4 |
               int(descriptor.trans_weight_1203) << 3 |
               int(descriptor.trans_output_1203) << 2 |
               int(descriptor.wrot180) << 1 | int(descriptor.no_bias))
    run_rs2 = (descriptor.activation << 3 | int(descriptor.input_dilated) << 2 |
               int(descriptor.downsample) << 1 | int(descriptor.no_pool))
    return (
        RoCCMicroOp(GemminiFunct.LOOP_CONV_WS_CONFIG_1, c1_rs1, c1_rs2),
        RoCCMicroOp(GemminiFunct.LOOP_CONV_WS_CONFIG_2, c2_rs1, c2_rs2),
        RoCCMicroOp(GemminiFunct.LOOP_CONV_WS_CONFIG_3, c3_rs1, c3_rs2),
        RoCCMicroOp(GemminiFunct.LOOP_CONV_WS_CONFIG_4, c4_rs1, c4_rs2),
        RoCCMicroOp(GemminiFunct.LOOP_CONV_WS_CONFIG_5,
                    descriptor.weights_addr, descriptor.output_addr),
        RoCCMicroOp(GemminiFunct.LOOP_CONV_WS_CONFIG_6,
                    descriptor.bias_addr, descriptor.input_addr),
        RoCCMicroOp(GemminiFunct.LOOP_CONV_WS, run_rs1, run_rs2),
    )
